# Carpeta APK

Coloca aquí el archivo APK oficial de Interneon VPN.

## Nombre recomendado:
- `interneon-vpn.apk`

## Instrucciones:
1. Sube el archivo APK con el nombre `interneon-vpn.apk`
2. El archivo será descargado automáticamente cuando los usuarios hagan clic en el botón "Descargar App"
3. Mantén este archivo actualizado con la última versión de la aplicación
